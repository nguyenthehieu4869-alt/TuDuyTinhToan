h,m=map(int,input().split())
s=h*60*60+m*60
print(s)