cost=int(input())
print(f'{(cost*1.4+10):.2f}')