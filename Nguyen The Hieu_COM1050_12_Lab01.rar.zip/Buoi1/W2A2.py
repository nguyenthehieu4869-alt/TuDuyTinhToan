n=input('name:')
print('Chào',n)