a,b=map(int,input().split())
a,b=b,a
print(a,b)