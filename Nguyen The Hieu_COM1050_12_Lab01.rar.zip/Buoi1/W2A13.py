a,b=map(int,input().split())
kq=(a*b)%10
print(kq)