c=float(input())
f=(9/5)*c+32
print(round(f,2))