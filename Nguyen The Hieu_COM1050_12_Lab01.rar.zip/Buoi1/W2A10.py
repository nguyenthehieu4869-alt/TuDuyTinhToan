a,b,c=input().split()
print(f'Hi {c},{b} and {a}')