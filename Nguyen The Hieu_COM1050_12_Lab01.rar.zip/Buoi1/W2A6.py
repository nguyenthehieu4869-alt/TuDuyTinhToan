a=input()
if len(a)==1 and 'a'<=a<='z':
    k=ord(a)
    print(k)
    print(chr(k-32))
else:
    print("nhập lại")
